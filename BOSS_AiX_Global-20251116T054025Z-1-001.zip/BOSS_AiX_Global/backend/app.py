# Flask Backend Entry
from flask import Flask
app = Flask(_name)

@app.route('/')
def home():
    return 'BOSS AiX Global Backend Running!'

if __name_ == '_main_':
    app.run(debug=True)