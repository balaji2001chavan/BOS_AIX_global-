# BOS_AIX_global-_with-_backend-
AI INTELLIGENT SMART APP project 
