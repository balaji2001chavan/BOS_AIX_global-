
# Boss AIX — Smart Universal Assistant
Created by You 💡 using Google Colab

## Features:
- Multi-language understanding (Marathi + 50+)
- Voice / Text input
- Auto UI with dynamic colors
- International-level branding ready

## How to use:
1. Run the Python script (BossAIX.py)
2. Open the UI (BossAIX_UI.html)
3. Enjoy your AI assistant!
